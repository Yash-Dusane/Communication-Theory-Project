function transmit_mod_op = Amp_Modulation(message, carrier)
    transmit_mod_op = message.*carrier;
end